export default function Page() {
  return <div className="p-10">Próximamente</div>;
}
